BUDGIE IN SUPER MARIO BROS.
- VER. 1.1 -

This ZIP includes: 

- Budgie in SMB1.ips - 
Patch this to an unmodified "Super Mario Bros. (World).nes" ROM with an IPS patcher.
This hack replaces art assets, names, etc with those of Budgie the parakeet!

- Box.png -
A box art for your use for anything that might need it - eg a modded NES Classic Edition or other emulator interface.

- readme.txt - 
Oh hey wow! That's this!


You probably already know this, but: direct any issues with the hack to Amby.

Oh, and stay rad!