AMBY IN SUPER MARIO WORLD


This ZIP includes: 

- Amby in SMW.ips - 
Patch this to an unmodified "Super Mario World (U) [!]" ROM with an IPS patcher.
This hack replaces art assets, names, etc with those of Amby the axolotl!

- Box.png -
A box art for your use for anything that might need it - eg a modded SNES Classic Edition or emulator interface

- readme.txt - 
Oh hey wow! That's this!


You probably already know this, but: direct any issues with the hack to Amby.

Oh, and have fun!